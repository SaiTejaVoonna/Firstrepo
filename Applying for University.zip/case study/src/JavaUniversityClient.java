
public class JavaUniversityClient {
	public static JavaUniversity university=JavaUniversity.getInstance();
    private static Student[] createStudents() {
        Student[] students = {
            new Student(1, "Gowrav", 7.5d),
            new Student(2, "Saurav", 5.5d),
            new Student(3, "Dhoni", 8.5d),
            new Student(4, "Virat", 3.5d),
            new Student(5, "Rohit", 9.5d),};
        try {
            for (Student st : students) {
                university.addStudent(st);
            }
        } catch (StudentLimitException se) {
            System.out.println(se.getMessage());
        }
        return students;
    }
 
    private static Course[] createCourses() {
        Course[] courses = {
            new Course(1, "Computer Science 101", 101),
            new Course(2, "Computer Science 102", 102),
            new Course(3, "Computer Science 103", 103),
            new Course(4, "Computer Science 104", 104),
            new Course(5, "Computer Science 105", 105),};
        try {
            for (Course c : courses) {
                university.addCourse(c);
            }
        } catch (CourseLimitException ce) {
            System.out.println(ce.getMessage());
        }
        return courses;
    }
 
    public static void main(String[] args) {
        Student[] students = createStudents();
        System.out.println("----JavaUniversity students ----");
        for (Student st : students) {
            System.out.print(st);
            System.out.println();
        }
 
        Course[] courses = createCourses();
        System.out.println("----JavaUniversity courses ----");
        for (Course c : courses) {
            System.out.print(c);
            System.out.println();
        }
        try {
        	//university.graduate(new Student(2, "Saurav", 5.5d));
        	university.graduate(new Student(3, "Dhoni", 8.5d));
        } catch(Exception e) {
        	System.out.println(e.getMessage());
        }
       
        
    }
}
