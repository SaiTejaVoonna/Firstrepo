
public class IneligibleForGraduateForException extends Exception {
	public IneligibleForGraduateForException(String msg) {
		super(msg);
	}

}
