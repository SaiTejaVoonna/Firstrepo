
public class JavaUniversity {
 
    private final int STUDENT_LIMIT = 5;
    private final int COURSE_LIMIT = 5;
    private final double MIN_GRADUATION_GPA = 7.0d;
    private static JavaUniversity jUniversity;
 
    private Student[] students;
    private Course[] courses;
 
    private int courseCount = 0;
    private int studentCount = 0;
 
    private JavaUniversity() {
        this.students = new Student[STUDENT_LIMIT];
        this.courses = new Course[COURSE_LIMIT];
    }
 
    public static JavaUniversity getInstance(){
        return new JavaUniversity();        
    }

    public void addCourse(Course c)throws CourseLimitException{
        if(courseCount < COURSE_LIMIT){
            this.courses[courseCount] = c;
            ++courseCount;
        }else{
           throw  new CourseLimitException("University Course limit reached !!!!");
        }
    }

     public void addStudent(Student st)throws StudentLimitException{
        if(studentCount < STUDENT_LIMIT){
            this.students[studentCount] = st;
            ++studentCount;
        }else{
           throw  new StudentLimitException("University Student limit reached !!!!");
        }
    }
     public void graduate(Student st)throws StudentNotFoundException, IneligibleForGraduateForException{
    	 boolean found=false;
    	 for(Student obg: this.students) {
    		 if(st.getName().equals(obg.getName())) {
    			 found=true;
    			 break;
    		 }
    	 }
    	 if(found) {
    		 if(st.getgpa() >= this.MIN_GRADUATION_GPA) {
    			 System.out.println("Congrats on Graduation");
    		 }
    		 else {
    			 throw new IneligibleForGraduateForException("Not eligible For Graduation ");
    			 
    		 }
    			 
    	 }
    	 else {
    		 throw new StudentNotFoundException("Student not found");
    	 }
     }

}
