
public class CourseLimitException extends Exception {
	public CourseLimitException(String msg) {
		super(msg);
	}

}
