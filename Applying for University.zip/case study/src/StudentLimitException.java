
public class StudentLimitException extends Exception {
	public StudentLimitException(String msg) {
		super(msg);
	}

}
